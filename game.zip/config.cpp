#include "config.h"

// 地图数据数组
char MAP[26][27];
